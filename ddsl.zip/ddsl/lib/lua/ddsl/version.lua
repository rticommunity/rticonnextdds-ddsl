return '1.0.0-rc-2015.10.09.mct-41-ga8674ac'
